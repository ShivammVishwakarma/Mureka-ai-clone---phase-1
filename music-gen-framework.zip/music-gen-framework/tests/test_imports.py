"""Regression tests for package structure and the documented public API.

These tests exist specifically to catch packaging regressions: if
``config/`` or ``utils/`` are ever flattened into the project root, or an
``__init__.py`` stops re-exporting a public name, these tests fail loudly
instead of surfacing as a confusing ``ModuleNotFoundError`` deep in a
notebook.

Run with: `pytest tests/test_imports.py -v`
"""

from __future__ import annotations

import importlib
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def test_config_and_utils_are_packages() -> None:
    """`config/` and `utils/` must exist as packages at the project root."""
    for pkg_name in ("config", "utils"):
        pkg_dir = PROJECT_ROOT / pkg_name
        assert pkg_dir.is_dir(), f"Expected package directory '{pkg_dir}' to exist"
        assert (pkg_dir / "__init__.py").is_file(), (
            f"'{pkg_dir}' is missing __init__.py and is not a valid package"
        )


@pytest.mark.parametrize(
    "module_path",
    [
        "config.schema",
        "config.settings",
        "utils.device",
        "utils.logging",
        "utils.seed",
        "utils.validation",
        "utils.audio_io",
    ],
)
def test_submodules_import(module_path: str) -> None:
    """Every documented submodule must import cleanly on its own."""
    importlib.import_module(module_path)


def test_documented_top_level_imports() -> None:
    """The two imports called out in the architecture docs must work."""
    from config import get_settings
    from utils import DeviceManager

    assert callable(get_settings)
    assert isinstance(DeviceManager, type)


def test_config_public_api() -> None:
    """`config/__init__.py` must re-export the full documented API."""
    import config

    expected = {
        "AudioConfig",
        "ColabConfig",
        "Config",
        "LoggingConfig",
        "ModelConfig",
        "PathConfig",
        "PrecisionMode",
        "RuntimeEnvironment",
        "TrainingConfig",
        "get_settings",
        "load_settings",
        "reset_settings",
    }
    missing = expected - set(config.__all__)
    assert not missing, f"config/__init__.py is missing exports: {missing}"
    for name in expected:
        assert hasattr(config, name), f"config.{name} not importable"


def test_utils_public_api() -> None:
    """`utils/__init__.py` must re-export the full documented API."""
    import utils

    expected = {
        "AudioLoadError",
        "AudioMetadata",
        "load_audio",
        "save_audio",
        "DeviceInfo",
        "DeviceManager",
        "get_logger",
        "setup_logging",
        "seed_worker",
        "set_global_seed",
        "ValidationError",
        "validate_choice",
        "validate_path_exists",
        "validate_positive",
        "validate_range",
        "validate_type",
    }
    missing = expected - set(utils.__all__)
    assert not missing, f"utils/__init__.py is missing exports: {missing}"
    for name in expected:
        assert hasattr(utils, name), f"utils.{name} not importable"


def test_settings_yaml_enum_coercion() -> None:
    """YAML-sourced enum fields (e.g. model.precision) must become real Enums.

    Regression guard for a bug where PyYAML strings like ``"auto"`` were
    passed straight into the dataclass instead of being coerced to
    ``PrecisionMode.AUTO``.
    """
    from config import PrecisionMode, get_settings, reset_settings

    reset_settings()
    settings = get_settings(config_path=str(PROJECT_ROOT / "config" / "example.yaml"), reload=True)
    assert isinstance(settings.model.precision, PrecisionMode)


def test_settings_override_priority() -> None:
    """Explicit overrides must win over env vars, which must win over YAML."""
    import os

    from config import PrecisionMode, load_settings, reset_settings

    reset_settings()
    os.environ["MGF_MODEL__PRECISION"] = "fp16"
    try:
        settings = load_settings(
            config_path=str(PROJECT_ROOT / "config" / "example.yaml"),
            overrides={"model": {"precision": PrecisionMode.BF16}},
        )
        assert settings.model.precision == PrecisionMode.BF16
    finally:
        del os.environ["MGF_MODEL__PRECISION"]
