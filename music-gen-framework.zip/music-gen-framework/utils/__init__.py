"""Utility package for the Music Gen Framework.

Provides cross-cutting infrastructure used throughout the framework:
device/precision management, logging, reproducibility, validation helpers,
and audio I/O — all independent of any specific model architecture.
"""

from __future__ import annotations

from utils.audio_io import AudioLoadError, AudioMetadata, load_audio, save_audio
from utils.device import DeviceInfo, DeviceManager
from utils.logging import get_logger, setup_logging
from utils.seed import seed_worker, set_global_seed
from utils.validation import (
    ValidationError,
    validate_choice,
    validate_path_exists,
    validate_positive,
    validate_range,
    validate_type,
)

__all__ = [
    "AudioLoadError",
    "AudioMetadata",
    "load_audio",
    "save_audio",
    "DeviceInfo",
    "DeviceManager",
    "get_logger",
    "setup_logging",
    "seed_worker",
    "set_global_seed",
    "ValidationError",
    "validate_choice",
    "validate_path_exists",
    "validate_positive",
    "validate_range",
    "validate_type",
]
